import csv
import re
import json
from collections import defaultdict

def load_claims(path='claims.csv'):
    claims = []
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            claims.append(row)
    return claims

def load_budgets(path='budgets.csv'):
    budgets = {}
    with open(path, newline='', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            budgets[row['category'].lower()] = int(row['limit_per_club'])
    return budgets

def parse_amount(note):
    # Find first number (allow commas) possibly preceded by Rs. or $ etc.
    m = re.search(r"(?:Rs?|\$)\s*([0-9,]+)", note, re.IGNORECASE)
    if not m:
        return None
    # Remove commas and convert to int
    try:
        return int(m.group(1).replace(',', ''))
    except ValueError:
        return None

def detect_category(note, categories):
    note_l = note.lower()
    for cat in categories:
        if cat in note_l:
            return cat
    return None

def has_bill(note):
    note_l = note.lower()
    # Simple heuristic: presence of word "bill", "receipt", "invoice", "ticket"
    return any(word in note_l for word in ["bill", "receipt", "invoice", "ticket"])

def main():
    claims = load_claims()
    budgets = load_budgets()
    categories = list(budgets.keys())
    # Running totals per (club, category)
    totals = defaultdict(int)
    # Prepare output writers
    payable_f = open('payable.csv', 'w', newline='', encoding='utf-8')
    review_f = open('review.csv', 'w', newline='', encoding='utf-8')
    results_f = open('results.csv', 'w', newline='', encoding='utf-8')
    payable_writer = csv.writer(payable_f)
    review_writer = csv.writer(review_f)
    results_writer = csv.writer(results_f)
    # Headers for results
    results_writer.writerow(['id','club','date','note','json'])
    # Write headers for payable and review (same as input)
    header = ['id','club','date','note']
    payable_writer.writerow(header)
    review_writer.writerow(header + ['reason'])
    summary_counts = defaultdict(int)
    for claim in claims:
        note = claim['note']
        amount = parse_amount(note)
        category = detect_category(note, categories)
        bill = has_bill(note)
        # Build JSON payload per spec
        payload = {
            "amount": amount,
            "category": category,
            "bill": bill,
            "summary": note[:30] + ('...' if len(note) > 30 else '')
        }
        # Determine status
        status = None
        reason = ''
        if amount is None:
            status = 'needs_more_info'
            reason = 'no amount'
        elif category is None:
            status = 'needs_more_info'
            reason = 'no category'
        elif not bill:
            status = 'needs_bill'
            reason = 'bill missing'
        else:
            # Check over budget
            key = (claim['club'], category)
            if totals[key] + amount > budgets.get(category, 0):
                status = 'over_budget'
                reason = 'budget exceeded'
            else:
                status = 'ok_to_pay'
                totals[key] += amount
                summary_counts[claim['club']] += amount
        # Write to appropriate output
        if status == 'ok_to_pay':
            payable_writer.writerow([claim['id'], claim['club'], claim['date'], claim['note']])
        else:
            review_writer.writerow([claim['id'], claim['club'], claim['date'], claim['note'], reason])
        # Write to results
        results_writer.writerow([claim['id'], claim['club'], claim['date'], claim['note'], json.dumps(payload)])
    # Close files
    payable_f.close()
    review_f.close()
    results_f.close()
    # Write summary.txt
    with open('summary.txt', 'w', encoding='utf-8') as sf:
        total_claims = len(claims)
        sf.write(f"Total claims processed: {total_claims}\n")
        sf.write(f"Payable claims: {sum(1 for c in claims if parse_amount(c['note']) is not None and detect_category(c['note'], categories) is not None and has_bill(c['note']) and (totals[(c['club'], detect_category(c['note'], categories))] <= budgets.get(detect_category(c['note'], categories),0))}\n")
        sf.write('Spending per club:\n')
        for club, amt in summary_counts.items():
            sf.write(f"  {club}: {amt}\n")

if __name__ == '__main__':
    main()
