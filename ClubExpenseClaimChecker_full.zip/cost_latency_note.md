# Cost & Latency Note

**Estimated API calls per day**: Approximately the number of claims processed (≈20) plus a few extra for red‑team inputs, so ~25 calls.

**Average latency per call**: ~200 ms (typical for a moderate‑size LLM request).

**Estimated cost**: Assuming a $0.0005 per request rate, the daily cost is <$0.02, well within a free‑tier budget.

*If you replace the rule‑based extraction with a real LLM, the numbers above give a rough upper bound.*
