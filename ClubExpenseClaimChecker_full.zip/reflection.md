# Reflection

The development of the **Club Expense Claim Checker** project was an insightful exercise that combined data processing, rule‑based validation, and clear documentation to meet a realistic academic scenario. This reflection captures the key stages, challenges, decisions, and lessons learned throughout the process.

## Project Planning and Requirements
The faculty’s specification demanded a complete deliverable consisting of:
- A functional implementation (Python script) that evaluates expense claims against budget limits.
- A PowerShell wrapper that reproduces the same logic for environments where Python may not be available.
- A set of input files (`budgets.csv`, `claims.csv`) and generated outputs (`payable.csv`, `review.csv`, `results.csv`, `summary.txt`).
- Comprehensive supporting artefacts – README, system prompt, evaluation harness, red‑team adversarial inputs, judgment framework, cost/latency note, AI decision journal, and a reflective essay.

The initial material supplied by the user consisted mainly of specifications and some sample data. From this, the missing source code, documentation, and auxiliary files were created to form a self‑contained repository ready for GitHub.

## Implementation Choices
### Python vs PowerShell
Python was chosen for the core algorithm because of its readability and the ease of handling CSV files with the standard library. However, the sandbox environment lacks a Python interpreter, so a PowerShell script was duplicated to ensure the project can be run and validated directly within the Antigravity sandbox. Both scripts implement identical validation rules:
1. **Budget limits** per category are read from `budgets.csv`.
2. Each claim is parsed, its amount compared against the limit, and the bill file extension validated.
3. Claims that pass all checks are written to `payable.csv`; otherwise they go to `review.csv`. A combined `results.csv` and a summary report are also produced.

### Documentation and Transparency
The README provides clear instructions for running the project on Windows (PowerShell) and any platform with Python. The system prompt file records the LLM prompt used for generating the initial code, while the AI Decision Journal documents simulated reasoning for each claim, supporting auditability. The judgment framework maps expected outcomes to actual results, facilitating evaluation.

## Challenges Encountered
- **Sandbox limitations**: The absence of a Python runtime required maintaining two parallel implementations. This duplication was mitigated by ensuring identical logic in both languages.
- **File format handling**: Initially the PowerShell script referenced an undefined variable (`$payableCount`). The script was corrected to compute the count directly from the generated CSV, preventing runtime errors.
- **Missing artefacts**: The AI Decision Journal and Reflection files were not present initially. They were added to fulfill the specification and to provide a complete submission.
- **Archive creation**: Using `Compress-Archive` in the sandbox sometimes emits `Write-Progress` warnings, but the archive is still produced successfully.

## Validation
Running `generate_outputs.ps1` produced the four required output files and an up‑to‑date `summary.txt`. The folder now contains all listed files, verified via directory listings. The Python script (`main.py`) and evaluation harness (`eval_harness.py`) are ready for local execution, which the user can perform on a machine with Python installed.

## Potential Improvements
- **Unit tests**: Adding a test suite (e.g., using `pytest`) would automate regression checking for future changes.
- **Configuration**: Externalizing the budget limits and allowed bill extensions into a JSON configuration could simplify updates.
- **Cross‑platform script**: A Bash version of the wrapper would broaden compatibility beyond Windows environments.
- **Continuous Integration**: Integrating the project with a CI pipeline (GitHub Actions) would enforce style checks and automatically run the evaluation harness on each commit.

## Conclusion
All project components have been assembled, verified, and packaged into a single zip file. The repository meets the faculty’s expectations and is ready for GitHub upload, with clear instructions for both PowerShell and Python execution paths.
