# AI Decision Journal

This journal records the simulated LLM's reasoning for each claim processed by the **Club Expense Claim Checker**. For each claim ID, the AI extracts the relevant fields, validates them against the budget constraints, and determines whether the claim is **Payable** or **Review**.

| Claim ID | Extracted JSON (excerpt) | Decision |
|----------|---------------------------|----------|
| C001 | `{ "club": "Chess Club", "category": "Equipment", "amount": 120.00, "bill": "chess_board.pdf" }` | Payable |
| C002 | `{ "club": "Drama Club", "category": "Costume", "amount": 250.00, "bill": "costume_receipt.jpg" }` | Review (exceeds $200 limit) |
| C003 | `{ "club": "Science Club", "category": "Materials", "amount": 75.50, "bill": "lab_supplies.pdf" }` | Payable |
| ... | ... | ... |

The AI follows these rules:
1. **Budget Check** – Each category has a maximum allowed amount (see `budgets.csv`). If a claim exceeds the limit, it is flagged for review.
2. **Format Validation** – The bill filename must have an allowed extension (`.pdf`, `.jpg`, `.png`). Invalid formats trigger a review.
3. **Completeness** – All fields (club, category, amount, bill) must be present; missing data results in a review.

The journal is provided for transparency and can be used by reviewers to audit the automated decisions.
