$ErrorActionPreference = 'Stop'

# Load budgets
$budgets = @{}
Import-Csv -Path 'budgets.csv' | ForEach-Object {
    $cat = $_.category.ToLower()
    $budgets[$cat] = [int]$_.limit_per_club
}

# Prepare totals per club+category
$totals = @{}

# Open output files
$payable = New-Object System.IO.StreamWriter('payable.csv')
$review = New-Object System.IO.StreamWriter('review.csv')
$results = New-Object System.IO.StreamWriter('results.csv')

# Write headers
$payable.WriteLine('id,club,date,note')
$review.WriteLine('id,club,date,note,reason')
$results.WriteLine('id,club,date,note,json')

function Parse-Amount($note) {
    if ($note -match '(?i)\b(?:Rs?|\$)\s*([0-9,]+)') {
        $num = $Matches[1] -replace ',', ''
        return [int]$num
    }
    return $null
}
function Detect-Category($note, $categories) {
    $lower = $note.ToLower()
    foreach ($c in $categories) {
        if ($lower -like "*$c*") { return $c }
    }
    return $null
}
function Has-Bill($note) {
    $lower = $note.ToLower()
    return $lower -match '\b(bill|receipt|invoice|ticket)\b'
}

$categories = $budgets.Keys
$summaryCounts = @{}
$claims = Import-Csv -Path 'claims.csv'
foreach ($claim in $claims) {
    $note = $claim.note
    $amount = Parse-Amount $note
    $category = Detect-Category $note $categories
    $bill = Has-Bill $note
    $payload = @{ amount = $amount; category = $category; bill = $bill; summary = $note.Substring(0, [Math]::Min(30,$note.Length)) }
    $json = $payload | ConvertTo-Json -Compress
    $status = ''
    $reason = ''
    if (-not $amount) { $status='needs_more_info'; $reason='no amount' }
    elseif (-not $category) { $status='needs_more_info'; $reason='no category' }
    elseif (-not $bill) { $status='needs_bill'; $reason='bill missing' }
    else {
        $key = "$($claim.club)|$category"
        $current = $totals[$key]
        if (-not $current) { $current = 0 }
        $limit = $budgets[$category]
        if ($current + $amount -gt $limit) { $status='over_budget'; $reason='budget exceeded' }
        else { $status='ok_to_pay'; $totals[$key] = $current + $amount; $reason='' }
    }
    if ($status -eq 'ok_to_pay') {
        $payable.WriteLine("$($claim.id),$($claim.club),$($claim.date),`"$note`"")
        if (-not $summaryCounts.ContainsKey($claim.club)) { $summaryCounts[$claim.club]=0 }
        $summaryCounts[$claim.club] += $amount
    } else {
        $review.WriteLine("$($claim.id),$($claim.club),$($claim.date),`"$note`",$reason")
    }
    $results.WriteLine("$($claim.id),$($claim.club),$($claim.date),`"$note`",$json")
}

$payable.Close()
$review.Close()
$results.Close()

# Write summary.txt
$summary = "Total claims processed: $($claims.Count)`n"
$summary += "Payable claims: $payableCount`n"
$summary += "Spending per club:`n"
foreach ($c in $summaryCounts.GetEnumerator()) {
    $summary += "  $($c.Key): $($c.Value)`n"
}
Set-Content -Path 'summary.txt' -Value $summary
