# Judgment Framework

| Claim ID | Expected Status | Actual Status (simulated) | Reason for Mismatch |
|----------|----------------|---------------------------|----------------------|
| C01 | ok_to_pay | ok_to_pay | – |
| C02 | needs_bill | needs_bill | – |
| C03 | needs_bill | needs_bill | – |
| C04 | ok_to_pay | ok_to_pay | – |
| C05 | ok_to_pay | ok_to_pay | – |
| C06 | ok_to_pay | ok_to_pay | – |
| C07 | over_budget | over_budget | Exceeds equipment limit for Drama Club |
| C08 | ok_to_pay | ok_to_pay | – |
| C09 | needs_more_info | needs_more_info | No amount nor category detected |
| C10 | ok_to_pay | ok_to_pay | – |
| C11 | ok_to_pay | ok_to_pay | – |
| C12 | ok_to_pay | ok_to_pay | – |
| C13 | ok_to_pay | ok_to_pay | – |
| C14 | needs_bill | needs_bill | – |
| C15 | ok_to_pay | ok_to_pay | – |
| C16 | ok_to_pay | ok_to_pay | – |
| C17 | ok_to_pay | ok_to_pay | – |
| C18 | needs_bill | needs_bill | – |
| C19 | ok_to_pay | ok_to_pay | – |
| C20 | over_budget | over_budget | Exceeds equipment limit for Robotics Club |

**Human checkpoint**: The faculty treasurer reviews every claim marked *ok_to_pay* and verifies the attached bill before signing the payment.
